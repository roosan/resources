#!/bin/bash
if [ $1 != "0" ]
then
	echo "这一步操作错误，请认真核查！！"
	exit 1
else
	echo "你是对的"
fi
