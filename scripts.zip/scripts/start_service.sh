#!/bin/bash
REDIS=/usr/local/redis
for REDIS_PORT in `ls $REDIS/conf`
do
	echo "$REDIS/src/redis-server $REDIS/conf/$REDIS_PORT" 2>>/home/dev/restart.txt
        $REDIS/src/redis-server $REDIS/conf/$REDIS_PORT 2>>/home/dev/restart.txt

done

#for CATALINA in `ls -d /usr/local/tomcat*`
#do
#	#跳过一个
#	$CATALINA/bin/startup.sh
#done 
