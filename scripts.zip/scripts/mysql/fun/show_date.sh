#!/bin/bash
#脚本根目录
SCRIPTS_ROOT=/home/dev/scripts/mysql
#执行一下对应的全局变量
source $SCRIPTS_ROOT/baserc
if [ -z "$1" ];then
    exit 1;
fi
printf "===================>>>>>>> " >> $LOG_DIR/ok.log
printf "%-60s" "`date  +"%Y年%m月%d日 %H:%M:%S"` $1"  >> $LOG_DIR/ok.log
printf " <<<<<<<===================\n"  >> $LOG_DIR/ok.log
