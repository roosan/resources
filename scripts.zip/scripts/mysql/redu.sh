#!/bin/bash
#功能描述：实现mysql还原到指定日期的版本
#还原的时候，按日期找到对应的目录和文件，根据命令还原数据。
#	全备份文件规则：跟back-all.sh里的文件规则一致
#   增量文件规则：跟back-incr.sh里的文件规则一致
#
#思路：
#1、获取传入的日期
#2、根据传入的日期通过mysql还原对应的全备份的文件
#3、根据传入的日期通过mysqlbinlog还原对应的增量备份文件
#4、通过mysql -e "reset master " -u$USERNAME -p$PASSWORD 清除还原产生的二进制文件
#作者: 庄君祥
#时间：2015年4月15日16:23:41
#版本：1.0

#脚本根目录
SCRIPTS_ROOT=/home/dev/scripts/mysql
#执行一下对应的全局变量
source $SCRIPTS_ROOT/baserc

#判断还原的时间节点是否合法
DATE=$1
if [ -z $DATE ];then
    echo "Please input the date what you want to redu!"
    exit 1;
fi
sh $SCRIPTS_ROOT/fun/show_date.sh "redu data begin"
#全备份文件名：备份根目录/年/月/日_all.sql
ALL_BACK_FILE=$REDU_DIR/`date -d $DATE +%Y`/`date -d $DATE +%m`/all.sql
if [ ! -f $ALL_BACK_FILE ];then
    echo "There is no sql file in $DATE";
    exit 1;
fi

#还原对应的全备份sql
mysql -u$USERNAME -p$PASSWORD < $ALL_BACK_FILE 2>> $LOG_DIR/error.log
sh $SCRIPTS_ROOT/fun/show_date.sh "redu complete version ok"

#增量备份文件名：备份根目录/年/月/日/logbin.*(最新的一个)
FILEDIR=$REDU_DIR/`date -d $DATE +%Y`/`date -d $DATE +%m`/`date -d $DATE +%d`
LOGBIN=""
for logbin in `ls -r $FILEDIR/logbin.*`
do
        LOGBIN=$logbin
        break;
done

if [ ! -f $LOGBIN ] ;then
        echo "logbin not exists;"
        exit 1;
fi
#还原对应的增量二进制文件
mysqlbinlog $LOGBIN | mysql 2>> $LOG_DIR/error.log
sh $SCRIPTS_ROOT/fun/show_date.sh "redu increment version ok"
#清除因为还原而产生的二进制文件
mysql -e "reset master " -u$USERNAME -p$PASSWORD
sh $SCRIPTS_ROOT/fun/show_date.sh "redu data over"
