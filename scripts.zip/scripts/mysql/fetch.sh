#!/bin/bash
#功能描述：从远程服务器抓取已经备份数所
# 	抓取的规则：根据日期，把一整月的数据全抓过来
#   	例子：/home/dev/mysql/back/2015/4
#
#思路：
#1、根据当前时间拷贝远程服务器的文件 通过scp来实现
#2、删除上个月服务器的备份数据（备份数据多保留一个月时长）通过ssh来执行rm
#
#作者: 庄君祥
#时间：2015年4月15日16:23:41
#版本：1.0

#脚本根目录
SCRIPTS_ROOT=/home/dev/scripts/mysql
#执行一下对应的全局变量
source $SCRIPTS_ROOT/baserc

#需要备份的日志目录
BACK_DATE_DIR="`date +%Y`/`date +%m`"
#目标目录，即抓取过来数据要存放的目录
TARGET_DIR=$FETCH_DIR/$BACK_DATE_DIR
#源目录，即抓取数据的目录
SOURCE_DIR=$BACK_DIR/$BACK_DATE_DIR

sh $SCRIPTS_ROOT/fun/show_date.sh "fetch back resource from format env begin"
if [ ! -f "$TARGET_DIR" ];then
	mkdir -p $TARGET_DIR
fi
#拷贝文件
scp -r -P10022 $SOURCE_USER@$SOURCE_IP:$SOURCE_DIR `dirname $TARGET_DIR` 2>>$LOG_DIR/error.log
sh $SCRIPTS_ROOT/fun/show_date.sh "fetch back resource from format env ok"

#删除当前时间向前推一个月备份数据
ssh -p10022 $SOURCE_USER@$SOURCE_IP  rm -rf $BACK_DIR/`date -d "-1 month" +%Y`/`date -d "-1 month" +%m` 
sh $SCRIPTS_ROOT/fun/show_date.sh "rm format env last month resource ok"
sh $SCRIPTS_ROOT/fun/show_date.sh "fetch back resource from format env over"
