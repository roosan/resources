#!/bin/bash
# 备份数据
mysqldump -uoperate -pzhy@12345@zhy --single-transaction --all-databases > backup_sunday_1_PM.sql
