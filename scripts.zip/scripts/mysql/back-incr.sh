#!/bin/bash
#功能描述:根据mysql的二进制日志，做增量备份
#备份的时候，按日期生成目录，并把最新的一份二进制日志拷贝过来
#   其中目录的规则：备份的根目录/年/月/日
#   二进制日志拷贝规则：根据时间逆序把最新的logbin文件拷贝
#   例子 ： 在/var/lib/mysql 目录下最新的logbin日志是logbin.000014
#           最终拷贝后的文件是:/home/dev/mysql/back/2015/4/15/logbin.000014
#思路：
#1、取到最新的logbin文件
#2、拷贝到规定的目录即可
#作者: 庄君祥
#时间：2015年4月15日
#版本：1.0

#脚本根目录
SCRIPTS_ROOT=/home/dev/scripts/mysql
#执行一下对应的全局变量
source $SCRIPTS_ROOT/baserc

sh $SCRIPTS_ROOT/fun/show_date.sh "back increment version begin"
##备份目录
FILEDIR=$BACK_DIR/`date +%Y`/`date +%m`/`date +%d`
#二进制文件名
LOGBIN=""
#取到最新的文件。这个方法比较笨。。。。啥时候再重构
for logbin in `ls -r $MYSQL_BACK/logbin.0*`
do
        LOGBIN=$logbin
        break;
done

#如果二进制不存在，则退出
if [ -z $LOGBIN ];then
        echo "logbin is not exists"
        exit 1
fi
if [ ! -f $FILEDIR ];then
		mkdir -p $FILEDIR
fi

#拷贝文件
cp -f $LOGBIN $FILEDIR 2>>$LOG_DIR/error.log
#给一个可读的权限
chmod 644 $FILEDIR
sh $SCRIPTS_ROOT/fun/show_date.sh "back increment version over"
