#!/bin/bash
#功能描述：实现mysql所有数据库的备份（除了几个系统自带的原始数据库外）
#备份的时候，按日期生成目录和文件。
#	其中目录的规则：备份的根目录/年/月
#   其中文件的规则：all.sql
#   例子 ： /home/dev/mysql/back/2015/4/all.sql
#把执行时的结果记录到日志中，日志共有两个：一个是成功日志，一个是失败日志
#
#思路：
#1、通过mysql命令找到所有的数据库
#2、通过grep排除系统自带的原始数据库
#3、通过mysqldump备份其余的所有库的所有数据
#一个月全备份一次

#作者: 庄君祥
#时间：2015年4月15日16:23:41
#版本：1.0

#脚本根目录
SCRIPTS_ROOT=/home/dev/scripts/mysql
#执行一下对应的全局变量
source $SCRIPTS_ROOT/baserc
source /etc/profile
#需要排除的数据库
EXCLUDE_DATABASE="Database|performance_schema|information_schema|mysql"

#生成日志目录
if [ ! -f $LOG_DIR ];then
    mkdir -p $LOG_DIR;
fi

sh $SCRIPTS_ROOT/fun/show_date.sh "back complete version begin"
#备份目录
FILEDIR=$BACK_DIR/`date  +%Y`/`date  +%m`
if [ ! -f $FILEDIR ];then
    mkdir -p $FILEDIR;
fi

#备份的文件
FILENAME="$FILEDIR/all.sql"

mysql -e "show databases;" -u${USERNAME} -p${PASSWORD} | grep -Ev $EXCLUDE_DATABASE | xargs mysqldump -u${USERNAME} -p${PASSWORD} --single-transaction --flush-logs --master-data=2 --databases >${FILENAME} 2>>$LOG_DIR/error.log 
sh $SCRIPTS_ROOT/fun/show_date.sh "back complete version over"
