#!/bin/bash
#时间：2015年3月24日15:35:37
#作者：庄君祥
#版本：1.0
#功能步骤说明：
#1、从hudson找出静态资源，拷贝到资源目录的src目录下,并删除.svn，并打成zip包
#2、从src目录复制一份到now目录
#3、删除/home/static下的（指定的，和zip包里文件夹名一样的）历史静态资源，把now复制过去并解压开
#4、把now的放一份到suc

ID=dev
USER=`who i am |awk '{ print $1  }'`
SCRIPTS_FUNC=/home/dev/scripts/func
RESOURCE=/home/dev/resource/static
HUDSON=/home/dev/.hudson
SRC=$RESOURCE/src
SUC=$RESOURCE/suc   
NOW=$RESOURCE/now
HOME=/home/static
STATICDIR=$HUDSON/jobs/1111_static/workspace
DATE=`date  +%Y%m%d%H%M`
LANG=zh_CN.UTF-8
#判断是否为dev 用户 

echo """
+--------------------------------------------------------------+
+---------------------部署脚本开始运行-------------------------+
+--------------------------------------------------------------+
+--------------------------------------------------------------+
+---------------确定特定用户执行,否则退出  --------------------|
+--------------------------------------------------------------+
+------------------当前系统时间为：$DATE-----------------------+
+--------------------------------------------------------------+
"""

if [ "$ID" != "$USER" ]
then
	echo "+-----------必须是dev用户才能执行操作！！-------------------+"
fi

#升级之前先确定是否有static包
if [ `ls $STATICDIR|wc -l` -eq 0 ]
then
	echo "没有需要更新的static,请核查hudson!"
	exit 1
fi

#创建升级所需要的文件夹
#将 /root/.hudson 下面的文件复制到 static/src/date文件里面
cd $SRC
if [ -e $DATE  ];then 
   rm -rf $SRC/$DATE
fi

echo "创建$SRC/$DATE,并复制到该文件夹里面"  
mkdir -p  $SRC/$DATE

cp -a $STATICDIR/* $SRC/$DATE
#修改.svn文件
find $SRC/$DATE -name ".svn"|xargs -i rm -rf {}
#修改wefileloader.js的时间戳
sed -i  s/"version = '?t=00002013'"/"version = '?t=`date +%Y%m%d%H%M%S`'"/g $SRC/$DATE/common/js/wefileloader.js
echo "已经更改wefileloader.js中的时间戳为`date +%Y%m%d%H%M%S`"

#压缩文件
cd $SRC/$DATE
echo "开始压缩$SRC/$DATE下的所有文件"
zip -r  static.zip ./* > /dev/null 2>&1
#删除原始文件
find ./ ! -name static.zip |xargs -i rm -rf {} >/dev/null 2>&1


#删除 now下的 所有 static文件,并复制hudson中的static文件
echo "存在 static包，现在删除$NOW 下的文件"
rm -rf $NOW/*
mkdir -p $NOW/$DATE
echo "开始复制static到now中"
cp -a $SRC/$DATE/static.zip  $NOW/$DATE

#删除/home/static下面的所有文件
echo "删除$HOME下面的所有文件"
cd $HOME
for static in `ls $STATICDIR` 
do 
	rm -rf $static
	echo "删除$static"
done

#复制 now中的文件到/home/static下
echo "复制$NOW/$DATE中的文件到$HOME下"
cp $NOW/$DATE/* $HOME

#unzip 解压
cd $HOME
unzip static.zip > /dev/null 2>&1
#加入检查机制
sh $SCRIPTS_FUNC/check_result.sh $?
echo "删除$HOME下的static.zip"
rm -rf static.zip

#将创建 suc/时间 文件夹
cd $SUC
if [ -e $DATE  ];then 
echo "+-$SUC/$DATE 文件夹已经存在，需要删除后重建--+"
   rm -rf $SUC/$DATE
fi
echo "创建$SUC/$DATE" 
mkdir -p  $SUC/$DATE
sh $SCRIPTS_FUNC/show_process.sh
#复制bak成功的文件到 suc文件夹里
echo "复制文件到$SUC/$DATE文件夹里"
cp -r $NOW/$DATE/* $SUC/$DATE

#回滚的时候使用
echo $DATE > $SCRIPTS_FUNC/static-time.txt
echo -e "==================>>>>>>>GOOD！所有发布操作已经结束 \n现在的时间是 `date +%F-%H:%S`"
