#!/bin/sh
#时间：2015年3月24日15:06:12
#版本：1.0
#作者：庄君祥
#功能步骤说明：
#1、从hudson取出war包，放到资源文件的now文件下
#2、把now备份一份到资源文件的src文件下
#3、删除原来应用的资源/usr/local/apps)
#4、把now的资源拷贝到应用的
#5、重启tomcat
#6、通过心跳接口 alive.html，探测tomcat是否正常启动
#7、如果正常启动，把这份备份到资源文件的suc文件下
#然后，就没有然后。。。。
#然后，就没有然后。。。。

cd ~
ID=dev
USER=`who i am |awk '{ print $1  }'`
#脚本目录
SCRIPTS_FUNC=/home/dev/scripts/func
HUDSON=/home/dev/.hudson
#war 存放的位置
RESOURCE=/home/dev/resource/war
#历史版本
SRC=$RESOURCE/src
#当前正在运行版本
NOW=$RESOURCE/now
#每次成功的版本
SUC=$RESOURCE/suc
#应用存放目录
APPS=/usr/local/apps
#所有有用的war。去掉一些需要排除的war包，比如web-share-common.war
ALLWAR=`find $HUDSON/jobs/0000_we-parent/workspace  -name *.war |grep -vf  $SCRIPTS_FUNC/useless-war.txt`
ALLWAR_SIZE=`find $HUDSON/jobs/0000_we-parent/workspace  -name *.war  |grep -vf  $SCRIPTS_FUNC/useless-war.txt | wc -l`
#发布的时间
DATE=`date +%Y%m%d%H%M`
LANG=zh_CN.UTF-8

echo """
+--------------------------------------------------------------+
+---------------------tomcat部署脚本开始运行-------------------+
+--------------------------------------------------------------+
+--------------------------------------------------------------+
+-------------需为dev用户执行,否则是一种坑爹的形为-------------+
+--------------------------------------------------------------+
+----------------------当前系统时间为：$DATE-------------------+
+--------------------------------------------------------------+
"""

#判断是否为dev 用户 
if [ "$ID" != "$USER" ]
	then
	echo "===================>>>>>必须是dev用户才能执行操作,您可能使用错误用户！！"
fi

#升级之前先确定是否有war包

if [ $ALLWAR_SIZE -eq 0  ]
	then
	echo "报错！$HUDSON中没有war包，请核查！！"
	exit 1
fi 

#创建升级所需要的文件夹
#将 /home/hudson/war 下面的文件移动到 war/src/date文件里面
echo "创建$SRC/$DATE,并复制到$DATE里面" 
cd $SRC
mkdir -p $SRC/$DATE

for war in $ALLWAR
do 
	cp -a $war $SRC/$DATE
done

#删除 now下的 所有 war包,并复制hudson中的war包
echo "开始复制war包到now中"  
rm -rf $NOW/*
mkdir -p $NOW/$DATE
cp -a $SRC/$DATE/* $NOW/$DATE

#删除/usr/local/apps下面的所有文件
echo "删除$APPS下面的所有文件"
rm -rf $APPS/*

#复制 now中的文件到/usr/local/apps下

echo "复制$NOW/$DATE中的文件到$APPS下"
cp $NOW/$DATE/*.war $APPS

#解压war
echo "开始解压war包到各自目录"
for war in `ls $APPS/*.war` 
do
	#去掉.war，通过字符串截取 
	unzip $war -d ${war%.*} >/dev/null 2>&1
	echo "解压 ${war}---->${war%.*}"
done
#删除所有war包
echo -n  "解压结束。\n除$APPS下的所有war包"
rm -rf $APPS/*.war

#重启 tomcat
echo """
+--------------------------------------------------------------+
| === 由于升级需要,需要重启tomcat进程，请耐心等待30秒。  === |
+--------------------------------------------------------------+

停止tomcat进程中，请稍后！
"""

#强制杀除进程
ps aux | grep tomcat | grep -v grep |awk '{print $2}'|xargs kill -9

echo "开启tomcat进程中，请稍后！"
for CATALINA_HOME in ls -d /usr/local/tomcat*
do
	$CATALINA_HOME/bin/startup.sh >/dev/null #2>&1
done
#给重启一个缓冲时间,30S
echo "给重启一个缓冲时间,请等待15s。。。。"
sh $SCRIPTS_FUNC/show_process.sh
sh $SCRIPTS_FUNC/show_process.sh
sh $SCRIPTS_FUNC/show_process.sh

#探包,看一下是否成功
for war in `ls $APPS` 
do
	#获取域名，去掉前面的web-
	sh $SCRIPTS_FUNC/isalive.sh ${war#*-}
done


#发布文件成功，将创建 suc/时间 文件夹
cd $SUC
if [ -e $DATE  ];then 
   rm -rf $SUC/$DATE
fi

mkdir -p $SUC/$DATE
echo "发布成功，复制文件到$SUC/$DATE文件夹里"
cp -a $NOW/$DATE/* $SUC/$DATE
sh $SCRIPTS_FUNC/show_process.sh

#回滚的时候使用
echo $DATE > $SCRIPTS_FUNC/tomcat-time.txt
echo """
把$DATE写到$SCRIPTS_FUNC/tomcat-time.txt中，回滚操作时使用！
====================>>>>>>>GOOD！成功！所有发布操作已经结束！
结束时间： `date +%F-%H:%S`
"""
