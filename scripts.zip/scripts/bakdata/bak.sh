#!/bin/bash
#安时间规则静态目录

#作者：庄君祥
#版本：1.0.0
#需要备份的静态目录
BACK_STATIC_DIR="upload uploads"
cd /home/static
rm -rf static.tar.gz
tar cf  static.tar.gz $BACK_STATIC_DIR
BACK_DIR=/home/dev/bakdata/`date +%Y`/`date +%m`/`date +%d`
if [ -f $BACK_DIR];then
	mkdir -p $BACK_DIR
fi
mv static.tar.gz $BACK_DIR
