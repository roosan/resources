#!/bin/bash
#把所有涉及到域名的备份一下
#再修改域名
#重启nginx
OLD_DOMAIN=$1
NEW_DOMAIN=$2
if [ -z $OLD_DOMAIN ];then
    echo "老域名不允许为空" 
    exit 1
fi
if [ -z $NEW_DOMAIN  ];then
    echo "新域名不允许为空" 
    exit 1
fi
sh /home/dev/scripts/domain/change_web_agent.sh  $OLD_DOMAIN $NEW_DOMAIN
sh /home/dev/scripts/domain/change_web_server.sh  $OLD_DOMAIN $NEW_DOMAIN
