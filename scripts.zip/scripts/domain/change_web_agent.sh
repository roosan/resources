#!/bin/bash
#把所有涉及到域名的备份一下
#再修改域名
#重启nginx
OLD_DOMAIN=$1
NEW_DOMAIN=$2
#修改nginx的配置文件
FILES="/usr/local/nginx/conf"
if [ -z $OLD_DOMAIN ];then
    echo "老域名不允许为空" 
    exit 1
fi
if [ -z $NEW_DOMAIN  ];then
    echo "新域名不允许为空" 
    exit 1
fi
echo "change agent files contains:$FILES"
echo "====================>>>>>>>>>before change"
grep $OLD_DOMAIN -r $FILES
sed -i "s/$OLD_DOMAIN/$NEW_DOMAIN/g" `grep $OLD_DOMAIN -rl $FILES`
echo "====================>>>>>>>>>afterhange"
grep $NEW_DOMAIN -r $FILES
service nginx restart
