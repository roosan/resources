#!/bin/sh
#progress 0-100%的一个小程序
function running(){
    b=''
    for ((i=0;i<=100;i+=2))
    do
            printf "progress:[%-50s]%d%%\r" $b $i
            sleep 0.03
            b=#$b
    done
    echo
}
#核查操作正确与否
check_result(){
	if [ $1 != "0" ]
	then
		echo "这一步操作错误，请认真核查！！"
		exit 1
	fi
}
echo "cd到/home/dev/static/suc 下"
cd /home/dev/resource/static/suc
DATE=`ls -n |tail -1 |awk '{ print $9 }'`
echo "查看需要上传的文件：$DATE"
echo "删除 1.202.135.129：/home/hudson/static下的所有文件"
ssh  -p10022 dev@1.202.135.129 rm -rf  /home/hudson/static/*
running
echo "上传所有static文件到1.202.135.129:/home/hudson/static 目录下"
scp -r -P10022 /home/dev/resource/static/suc/$DATE/* dev@1.202.135.129:/home/hudson/static
check_result $?
echo "执行1.202.135.129：/home/dev 下的 自动化发布脚本 "
ssh  -p10022 dev@1.202.135.129  /bin/sh /home/dev/static-up.sh
check_result $?

