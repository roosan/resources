#!/bin/sh

#progress 0-100%的一个小程序
function running(){
    b=''
    for ((i=0;i<=100;i+=2))
    do
            printf "progress:[%-50s]%d%%\r" $b $i
            sleep 0.03
            b=#$b
    done
    echo
}

#核查操作正确与否

check_result(){
	if [ $1 != "0" ]
	then
		echo "这一步操作错误，请认真核查！！"
		exit 1
	fi
}
echo "cd到/home/dev/war/suc 下"
cd /home/dev/resource/war/suc
DATE=`ls -n |tail -1 |awk '{ print $9 }'`
echo "查看需要上传的文件：$DATE"
check_result $?
echo "删除 1.202.135.130：/home/dev/resource/war下的所有文件"
#ssh  -p10022 dev@1.202.135.130 rm -rf  /home/dev/war/*
running
echo "上传所有war文件到1.202.135.130:/home/dev/resource/war 目录下"
scp -r -P10022 /home/dev/resource/war/suc/$DATE/* dev@1.202.135.130:/home/hudson/war
check_result $?
echo "执行1.202.135.130：/home/dev 下的 自动化发布脚本 "
source  ~/.bash_profile
source  /etc/profile 
ssh  -p10022 dev@1.202.135.130  "source  /etc/profile;/bin/sh /home/dev/tom-up.sh"
check_result $?



