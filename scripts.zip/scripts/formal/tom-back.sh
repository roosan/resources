
#!/bin/sh
ID=dev
USER=`who i am |awk '{ print $1  }'`
HUDSON=/root/.hudson
SRC=/home/dev/war/src
SUC=/home/dev/war/suc   
NOW=/home/dev/war/now
APPS=/usr/local/apps
DATE=`date  +%Y%m%d%H%M`

BACKTIME=`cat /home/dev/tomcat-time.txt`

#progress 0-100%的一个小程序
function running(){
    b=''
    for ((i=0;i<=100;i+=2))
    do
            printf "progress:[%-50s]%d%%\r" $b $i
            sleep 0.04
            b=#$b
    done
    echo
}

#核查操作正确与否

check_result(){
	if [ $1 != "0" ]
	then
		echo "这一步操作错误，请认真核查！！"
		exit 1
	fi
}

#判断是否为dev 用户 

echo "+--------------------------------------------------------------+"
echo "+---------------------回滚脚本开始运行-------------------------+"
echo "+--------------------------------------------------------------+"
echo "+--------------------------------------------------------------+"
echo "+---------------需为dev用户执行,否则退出  --------------------|"
echo "+--------------------------------------------------------------+"

if [ "$ID" != "$USER" ]
then
echo "+-----------必须是dev用户才能执行操作！！-------------------+"
exit 1
fi
echo ""

if [ "$BACKTIME" = ""  ];then
echo "没有需要回滚的war包"
exit 1
fi
echo ""
echo "开始回滚操作！"
echo ""
echo "删除 $APPS下的所有文件"
rm -rf $APPS/*

echo "把suc中的文件放到$APPS中"
cp -a $SUC/$BACKTIME/* $APPS

echo "删除$NOW中的所有文件"

rm -rf $NOW/*
echo "把suc中的文件放到$NOW中"
mkdir -p $NOW/$DATE
cp -a $SUC/$BACKTIME/* $NOW/$DATE

#解压
echo "开始解压war包到各自目录"

cd $APPS
LS=`ls *.war`
for war in $LS 
do 
a=`echo "$war"|awk '{print length($0)}'`
b=4
(( c=$a-$b  ))
A=`echo "$war"|awk  -F  /  '{print $NF}'|cut -c1-"$c"`
echo "解压$war中。。。"
unzip $war -d $A >/dev/null 2>&1
#加入检查机制
check_result $?
done
#删除所有war包
echo  "删除$APPS下的所有war包"
rm -rf $APPS/*.war
#重启 tomcat
echo ""
echo "+--------------------------------------------------------------+"
echo '| === 由于升级需要,需要重启tomcat进程，请耐心等待30秒。  === |'
echo "+--------------------------------------------------------------+"
echo ""
echo  "停止tomcat进程中，请稍后！"
#强制杀除进程
PID=`ps -ef |grep tomcat |grep -v grep |awk '{ print $2  }'`

if [ "$PID" != "" ]; then
echo ""
echo  "正在强制杀除tomcat进程!"
echo ""
for pid in $PID
do
kill -9 $pid
echo "已经杀死进程$pid"
sleep 1 
done 
fi

echo "开启tomcat进程中，请稍后！"
/etc/init.d/tomcat start >/dev/null 2>&1
ps -ef |grep tomcat
#给重启一个缓冲时间,30S
echo ""
echo "给重启一个缓冲时间,请等待15s。。。。"
running
sleep 5
running

#探包

#CURL=`curl -o /dev/null -s -w %{http_code} "http://sso.sxw100.com"`

CURLSSO=`curl http://sso.uxuexi.com/alive.html`
B=`echo $CURLSSO |wc -L` 
if [  $B -ne 11 ]
then
echo ""
echo "sso服务启动失败，请检查日志，如有需要请回滚操作"
exit 1
else
echo ""
echo "GOOD，sso服务启动成功！！！"
fi

CURLZHY=`curl http://www.uxuexi.com/alive.html`
C=`echo $CURLZHY |wc -L` 
if [  $C -ne 11 ]
then
echo ""
echo "zhy服务启动失败，请检查日志，如有需要请回滚操作"
exit 1
else
echo ""
echo "GOOD，zhy服务启动成功！！！"
fi

CURLMANAGE=`curl http://manage.uxuexi.com/alive.html`
D=`echo $CURLMANAGE |wc -L` 
if [  $D -ne 11 ]
then
echo ""
echo "manage服务启动失败，请检查日志，如有需要请回滚操作"
exit 1
else
echo ""
echo "GOOD，manage服务启动成功！！！"
fi

# 回滚脚本成功
echo ""
echo "GOOD！成功！所有回滚操作已经结束！"
echo ""
echo  "结束时间： `date +%F-%H:%S`"
