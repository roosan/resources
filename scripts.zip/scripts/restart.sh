#!/bin/bash
#redis启动
REDIS_CONF=/usr/local/redis/conf
for REDIS in `ls $REDIS_CONF`
do
echo $REDIS
        /usr/local/redis/src/redis-server /usr/local/redis/conf/$REDIS 2>>/home/dev/restart.txt
done

#tomcat启动
for CATALINA in `ls -d /usr/local/tomcat*`
do
	echo $CATALINA
	$CATALINA/bin/startup.sh
done

#hudson启动
/home/hudson/bin/startup.sh
