#!/bin/sh
cd ~
ID=dev
USER=`who i am |awk '{ print $1  }'`
HUDSON=/root/.hudson
SRC=/home/dev/war/src
SUC=/home/dev/war/suc   
NOW=/home/dev/war/now
APPS=/usr/local/apps
WAR=`find /home/dev/.hudson/jobs/0000_we-parent -name *.war |grep workspace |wc -l`
ALLWAR=`find /home/dev/.hudson/jobs/0000_we-parent  -name *.war |grep workspace`
DATE=`date +%Y%m%d%H%M`
LANG=zh_CN.UTF-8
#progress 0-100%的一个小程序
function running(){
    b=''
    for ((i=0;i<=100;i+=2))
    do
            printf "progress:[%-50s]%d%%\r" $b $i
            sleep 0.03
            b=#$b
    done
    echo
}
#核查操作正确与否

check_result(){
	if [ $1 != "0" ]
	then
		echo "这一步操作错误，请认真核查！！"
		exit 1
	fi
}
#判断是否为dev 用户 

echo "+--------------------------------------------------------------+"
echo "+---------------------tomcat部署脚本开始运行-------------------+"
echo "+--------------------------------------------------------------+"
echo "+--------------------------------------------------------------+"
echo "+---------------需为dev用户执行,否则退出  --------------------|"
echo "+--------------------------------------------------------------+"

if [ "$ID" != "$USER" ]
then
echo "+-----------必须是dev用户才能执行操作！！-------------------+"
#exit 1
fi
echo ""
echo ""
#查询当前系统时间
echo  "+-------------当前系统时间为：$DATE-----------------------+"
echo ""

#升级之前先确定是否有war包

if [ $WAR -eq 0  ]
then
echo "报错！$HUDSON中没有war包，请核查！！"
exit 1
fi 

#创建升级所需要的文件夹
#将 /home/hudson/war 下面的文件移动到 war/src/date文件里面
cd $SRC
if [ -e $DATE  ];then 
echo "+-$SRC/$DATE 文件夹已经存在，需要删除后重建--+"
   rm -rf $SRC/$DATE
    running
   echo "创建$SRC/$DATE,并复制到$DATE里面" 
   mkdir -p $SRC/$DATE
   #加入检查机制
   check_result $?
  
for allwar in $ALLWAR
do 
cp -a $allwar $SRC/$DATE
 check_result $?
done

#把无用war包放在 /home/dev/useless-war下
echo "开始把无用war包放在 /home/dev/useless-war/$DATE下"
mkdir -p /home/dev/useless-war/$DATE
NOWAR=`cat  /home/dev/useless-war.txt`
cd $SRC/$DATE
for useless in $NOWAR
do
  mv $useless /home/dev/useless-war/$DATE
   echo "已经把$useless移动到/home/dev/useless-war/$DATE下" 
done

else
   echo "创建$SRC/$DATE,并复制到$DATE里面" 
   mkdir -p $SRC/$DATE
   #加入检查机制
   check_result $?
   for allwar in $ALLWAR
do 
cp -a $allwar $SRC/$DATE
 check_result $?
done

#把无用war包放在 /home/dev/useless-war下
echo "开始把无用war包放在 /home/dev/useless-war/$DATE下"
mkdir -p /home/dev/useless-war/$DATE
NOWAR=`cat  /home/dev/useless-war.txt`
cd $SRC/$DATE
for useless in $NOWAR
do
  mv $useless /home/dev/useless-war/$DATE
   echo "已经把$useless移动到/home/dev/useless-war/$DATE下" 
done

fi


#删除 now下的 所有 war包,并复制hudson中的war包
echo "存在 war包，现在删除$NOW下的文件"
rm -rf $NOW/*
mkdir -p $NOW/$DATE
#加入检查机制
check_result $?
echo "开始复制war包到now中"  
cp -a $SRC/$DATE/* $NOW/$DATE
 check_result $?

#删除/usr/local/apps下面的所有文件
cd $APPS
echo "删除$APPS下面的所有文件"
rm -rf ./*

#复制 now中的文件到/usr/local/apps下

echo "复制$NOW/$DATE中的文件到$APPS下"
cp $NOW/$DATE/*.war $APPS
check_result $?

#解压
echo "开始解压war包到各自目录"
cd $APPS
LS=`ls *.war`
for war in $LS 
do 
a=`echo "$war"|awk '{print length($0)}'`
b=4
(( c=$a-$b  ))
A=`echo "$war"|awk  -F  /  '{print $NF}'|cut -c1-"$c"`
echo "解压$war中。。。"
unzip $war -d $A >/dev/null 2>&1
#加入检查机制
check_result $?
done
#删除所有war包
echo "解压结束。"
echo  "删除$APPS下的所有war包"
rm -rf $APPS/*.war

#重启 tomcat
echo ""
echo "+--------------------------------------------------------------+"
echo '| === 由于升级需要,需要重启tomcat进程，请耐心等待30秒。  === |'
echo "+--------------------------------------------------------------+"
echo ""
echo  "停止tomcat进程中，请稍后！"
#强制杀除进程
PID=`ps -ef |grep tomcat |grep -v grep |awk '{ print $2  }'`

if [ "$PID" != "" ]; then
echo ""
echo  "正在强制杀除tomcat进程!"
echo ""
for pid in $PID
do
kill -9 $pid
echo "已经杀死进程$pid"
sleep 1 
done 
fi

echo "开启tomcat进程中，请稍后！"
/etc/init.d/tomcat start >/dev/null 2>&1
ps -ef |grep tomcat
#给重启一个缓冲时间,30S
echo ""
echo "给重启一个缓冲时间,请等待15s。。。。"
running
sleep 5
running

#探包

#CURL=`curl -o /dev/null -s -w %{http_code} "http://sso.sxw100.com"`

CURLSSO=`curl http://sso.uxuexi.com/alive.html`
B=`echo $CURLSSO |wc -L` 
if [  $B -ne 11 ]
then
echo ""
echo "sso服务启动失败，请检查日志，如有需要请回滚操作"
exit 1
else
echo ""
echo "GOOD，sso服务启动成功！！！"
fi

CURLZHY=`curl http://www.uxuexi.com/alive.html`
C=`echo $CURLZHY |wc -L` 
if [  $C -ne 11 ]
then
echo ""
echo "zhy服务启动失败，请检查日志，如有需要请回滚操作"
exit 1
else
echo ""
echo "GOOD，zhy服务启动成功！！！"
fi

CURLMANAGE=`curl http://manage.uxuexi.com/alive.html`
D=`echo $CURLMANAGE |wc -L` 
if [  $D -ne 11 ]
then
echo ""
echo "manage服务启动失败，请检查日志，如有需要请回滚操作"
exit 1
else
echo ""
echo "GOOD，manage服务启动成功！！！"
fi

#发布文件成功，将创建 suc/时间 文件夹
cd $SUC
if [ -e $DATE  ];then 
   echo ""
echo "+-$SUC/$DATE 文件夹已经存在，需要删除后重建--+"
   rm -rf $SUC/$DATE
   echo "创建$SUC/$DATE文件夹" 
   mkdir -p  $SUC/$DATE
   #加入检查机制
   check_result $?
   echo ""
   echo "发布成功，复制文件到$SUC/$DATE文件夹里"
   cp -a $NOW/$DATE/* $SUC/$DATE
   running
else
   echo ""
   echo "创建$SUC/$DATE文件夹" 
   mkdir -p $SUC/$DATE
   #加入检查机制
   check_result $?
   echo ""
   echo "发布成功，复制文件到$SUC/$DATE文件夹里"
   cp -a $NOW/$DATE/* $SUC/$DATE
   running
fi

#回滚的时候使用
echo "把$DATE写到/home/dev/tomcat-time.txt中，回滚操作时使用！"
echo $DATE > /home/dev/tomcat-time.txt
running
echo ""
echo "GOOD！成功！所有发布操作已经结束！"
echo ""
echo  "结束时间： `date +%F-%H:%S`"



