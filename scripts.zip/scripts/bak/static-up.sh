#!/bin/bash
ID=dev
USER=`who i am |awk '{ print $1  }'`
HUDSON=/root/.hudson
SRC=/home/dev/static/src
SUC=/home/dev/static/suc   
NOW=/home/dev/static/now
HOME=/home/static
STATIC=`ls /home/dev/.hudson/jobs/1111_static/workspace|wc -l`
STATICLS=`ls /home/dev/.hudson/jobs/1111_static/workspace`
STATICDIR=/home/dev/.hudson/jobs/1111_static/workspace
DATE=`date  +%Y%m%d%H%M`
LANG=zh_CN.UTF-8
#progress 0-100%的一个小程序
function running(){
    b=''
    for ((i=0;i<=100;i+=2))
    do
            printf "progress:[%-50s]%d%%\r" $b $i
            sleep 0.04
            b=#$b
    done
    echo
}

#核查操作正确与否

check_result(){
	if [ $1 != "0" ]
	then
		echo "这一步操作错误，请认真核查！！"
		exit 1
	fi
}

#判断是否为dev 用户 

echo "+--------------------------------------------------------------+"
echo "+---------------------部署脚本开始运行-------------------------+"
echo "+--------------------------------------------------------------+"
echo "+--------------------------------------------------------------+"
echo "+---------------确定特定用户执行,否则退出  --------------------|"
echo "+--------------------------------------------------------------+"

if [ "$ID" != "$USER" ]
then
echo "+-----------必须是dev用户才能执行操作！！-------------------+"
#exit 1
fi
echo ""
echo ""
#查询当前系统时间
echo  "+-------------当前系统时间为：$DATE-----------------------+"
echo ""

#升级之前先确定是否有static包
#echo $STATIC
if [ $STATIC -eq 0 ]
then
echo "没有需要更新的static,请核查!"
exit 1
fi

#创建升级所需要的文件夹
#将 /root/.hudson 下面的文件复制到 static/src/date文件里面
cd $SRC
if [ -e $DATE  ];then 
echo "+-$SRC/$DATE 文件夹已经存在，需要删除后重建--+"
   rm -rf $SRC/$DATE
echo "创建$SRC/$DATE,并复制到该文件夹里面"  
   mkdir -p  $SRC/$DATE
   running
   cd $STATICDIR
   cp -a ./* $SRC/$DATE
else
   echo "创建$SRC/$DATE,并复制到该文件夹里面" 
   mkdir -p $SRC/$DATE
   cd $STATICDIR
   cp -a ./* $SRC/$DATE
   running
fi


#修改wefileloader.js的时间戳
sed -i  s/"version = '?t=00002013'"/"version = '?t=`date +%Y%m%d%H%M%S`'"/g $SRC/$DATE/common/js/wefileloader.js
echo "已经更改wefileloader.js中的时间戳为`date +%Y%m%d%H%M%S`"

#压缩文件
cd $SRC/$DATE
echo "开始压缩$SRC/$DATE下的所有文件"

zip -r  static.zip $STATICLS > /dev/null 2>&1


#删除 now下的 所有 static文件,并复制hudson中的static文件

echo "存在 static包，现在删除$NOW 下的文件"
rm -rf $NOW/*
mkdir -p $NOW/$DATE
echo "开始复制static到now中"
cp -a $SRC/$DATE/static.zip  $NOW/$DATE

#删除/home/static下面的所有文件
echo "删除$HOME下面的所有文件"
cd $HOME
for static in $STATICLS
do 
rm -rf $static
echo "删除$static"
#sleep  3
done

#复制 now中的文件到/home/static下
echo "复制$NOW/$DATE中的文件到$HOME下"
cp $NOW/$DATE/* $HOME

#unzip 解压
cd $HOME
unzip static.zip > /dev/null 2>&1
#加入检查机制
check_result $?
echo "删除$HOME下的static.zip"
rm -rf static.zip

#将创建 suc/时间 文件夹
cd $SUC
if [ -e $DATE  ];then 
echo "+-$SUC/$DATE 文件夹已经存在，需要删除后重建--+"
   rm -rf $SUC/$DATE
   running
   echo "创建$SUC/$DATE" 
   mkdir -p  $SUC/$DATE
   running
#复制bak成功的文件到 suc文件夹里
 echo "复制文件到$SUC/$DATE文件夹里"
 cp -r $NOW/$DATE/* $SUC/$DATE
else
   echo "创建$SUC/$DATE" 
   mkdir -p $SUC/$DATE
   running
#复制bak成功的文件到 suc文件夹里
 echo "复制文件到$SUC/$DATE文件夹里"
 cp -r $NOW/$DATE/* $SUC/$DATE
fi

#回滚的时候使用
echo $DATE > /home/dev/static-time.txt
#running
echo "GOOD！所有发布操作已经结束"
echo  "现在的时间是 `date +%F-%H:%S`"


