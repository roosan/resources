#!/bin/bash

#备份tomcat
for tomcat in `ls -d /usr/local/tomcat*/conf`
do
	SOURCE_DIR=`dirname $tomcat`
	TARGET_DIR=conf/${SOURCE_DIR:11}
	mkdir -p ${TARGET_DIR}
	cp  $tomcat/server.xml $tomcat/web.xml  ${TARGET_DIR}
done

tar cvf tomcat.conf.tar.gz conf
