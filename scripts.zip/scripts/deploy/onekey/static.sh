#!/bin/bash
#脚本根目录
SCRIPTS_ROOT=/home/dev/scripts/deploy
#执行一下对应的全局变量
source $SCRIPTS_ROOT/baserc

sh $SCRIPTS_ROOT/make/static.sh 2>>$LOG_DIR/error.log
sh $SCRIPTS_ROOT/deploy/static.sh 2>>$LOG_DIR/error.log

