#!/bin/bash
#脚本根目录
SCRIPTS_ROOT=/home/dev/scripts/deploy
#执行一下对应的全局变量
source $SCRIPTS_ROOT/baserc

sh $SCRIPTS_ROOT/make/war.sh 
sh $SCRIPTS_ROOT/deploy/war.sh 
sh $SCRIPTS_ROOT/email/send.sh
