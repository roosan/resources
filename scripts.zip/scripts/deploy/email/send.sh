#!/bin/sh
# automail.sh
#脚本目录
DIR=/home/dev/scripts/deploy/email
#邮件内容
mailcontent=$DIR/mailcontent
#邮件发布的环境
EMAIL_ENV="测试环境"
#构建的目录，即hudson目录
BUILDS_DIR=/home/dev/.hudson/jobs/0000_we-parent/builds/
#发送的邮件地址
TARGET_EMAIL=dev@uxuexi.com

#清除上一次邮件发送内容
> "$mailcontent"
echo -e "大神，您好!我又悄悄在$EMAIL_ENV发布啦。此次发布内容如下：\n" >> $mailcontent
#最新构建的目录
LASTER=`ls -rt $BUILDS_DIR |grep -v "-"| grep -v "_"|tail -1`
DEPLOY_COTENT=`grep -E "^\s{4}.*|committer" $BUILDS_DIR$LASTER/changelog.xml`
if [ $DEPLOY_COTENT=""  ];then
	echo -e "这才发布没有新的更新，涛声依旧啊！" >>$mailcontent
else
	echo -e $DEPLOY_COTENT >>$mailcontent
fi
echo -e "\t发布时间为： `date +"%Y-%m-%d %H:%M:%S"` 敬请查收。" >> $mailcontent
cat $mailcontent | /usr/bin/mutt -s "$EMAIL_ENV发布通知" $TARGET_EMAIL
