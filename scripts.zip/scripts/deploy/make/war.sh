#!/bin/bash
#功能描述：加工处理动态资源，把开发的资源变为服务器可直接使用资源
#	这里获取hudson已经加工过的war包
#
#思路：
#	通过find找到指定的war,把这些war放到指定的目录，指定目录的规则：根据当前发布的时间，创建目录

#作者: 庄君祥
#时间：2015年4月27日15:36:34
#版本：1.0

#脚本根目录
SCRIPTS_ROOT=/home/dev/scripts/deploy
#执行一下对应的全局变量
source $SCRIPTS_ROOT/baserc

#找war的指定
WAR_COMMAND="find $WAR_DIR -name *.war |grep -vf  $SCRIPTS_ROOT/make/useless-war.txt"
#存放war的目录
FILE_DIR=$WAR_SRC/`date +%Y-%m-%d.%H-%M-%S`

#升级之前先确定是否有war包
#这里的eval是为了解决变量不能执行命名的冲突问题。
if [ `eval "$WAR_COMMAND | wc -l"` -eq 0  ];then
    echo "报错！$HUDSON中没有war包，请核查！！"
    exit 1
fi

#创建升级所需要的文件夹
mkdir -p $FILE_DIR

#把找到的war放到指定的目录 
`eval "$WAR_COMMAND|xargs -i cp -a  {} $FILE_DIR"` 
