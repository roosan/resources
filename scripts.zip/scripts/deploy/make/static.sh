#!/bin/bash
#功能描述：加工处理静态资源，把开发的资源变为服务器可直接使用资源
#	这里获取hudson的静态资源，经过一系统处理，变成可以正式访问的静态资源
#
#思路：
#1、取到hudson的静态文件并且删除.svn
#2、修改seajs的配置文件，支持版本管理，清除浏览器缓存文件
#3、把成zip包
#4、放到指定的目录。指定目录规则：根据当前发布的时间，创建目录
#作者: 庄君祥
#时间：2015年4月15日16:23:41
#版本：1.0

#脚本根目录
SCRIPTS_ROOT=/home/dev/scripts/deploy
#执行一下对应的全局变量
source $SCRIPTS_ROOT/baserc

#存放static的目录
FILE_DIR=$STATIC_SRC/`date +%Y-%m-%d.%H-%M-%S`

#升级之前先确定是否有static包
if [ `ls $STATIC_DIR|wc -l` -eq 0 ]
then
    echo "没有需要更新的static,请核查hudson!"
    exit 1
fi

mkdir -p $FILE_DIR
cp  -r $STATIC_DIR/* $FILE_DIR
#删除.svn文件
find $FILE_DIR -name ".svn"|xargs -i rm -rf {}

#修改wefileloader.js的时间戳
sed -i  s/"version = '?t=00002013'"/"version = '?t=`date +%Y%m%d%H%M%S`'"/g $FILE_DIR/common/js/wefileloader.js

#压缩文件
cd $FILE_DIR
zip -r  static.zip ./* > /dev/null 2>&1
#删除原始文件
find ./ ! -name static.zip |xargs -i rm -rf {} >/dev/null 2>&1 
