#!/bin/bash
PROJECT=$1
CURL=`curl http://$PROJECT.uxuexi.com/alive.html`
B=`echo $CURL |wc -L`
if [  $B -ne 11 ]
then
		echo "$PROJECT服务启动失败，请检查日志，如有需要请回滚操作"
		exit 1
else
		echo "GOOD,$PROJECT服务启动成功！！！"
fi
