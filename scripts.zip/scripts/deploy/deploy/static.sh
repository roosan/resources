#!/bin/bash
#功能描述：把加工好的zip包，放到指定的静态资源目录
#
#思路：
#1、删除服务器正在执行的资源
#2、获取最新一份资源，放到服务器
#3、解压zip
#4、保存版本

#作者: 庄君祥
#时间：2015年4月15日16:23:41
#版本：1.0

#脚本根目录
SCRIPTS_ROOT=/home/dev/scripts/deploy
#执行一下对应的全局变量
source $SCRIPTS_ROOT/baserc
#不需要删除的脚本
UNNEEDTORM="uploadroot|uploads"

#最新的版本目录   
LASTER_DIR=`ls -n $STATIC_SRC|tail -1| awk '{print $9}'` 

#需要删除的文件,即zip第一层目录
STATIC_LS=`zipinfo -2 $STATIC_SRC/$LASTER_DIR/static.zip |awk -F / '{ print $1  }'|uniq`

#删除/home/static下面的对应的项目上有的文件夹
cd $STATIC_APPS
for static in $STATIC_LS
do
	#如果是指定的文件，则不删除
	if [[ "$UNNEEDTORM" =~ "$static"  ]];then
		continue
	fi
    rm -rf $STATIC_APPS/$static
    echo "删除$static"
done

#复制 now中的文件到/home/static下
cp $STATIC_SRC/$LASTER_DIR/* $STATIC_APPS

#unzip 解压
cd $STATIC_APPS
#不覆盖原来的文件
unzip  -n  static.zip > /dev/null 2>&1
#加入检查机制
echo "删除$HOME下的static.zip"
rm -rf static.zip

#将创建 suc/时间 文件夹
FILE_DIR=$STATIC_SUC/$LASTER_DIR
mkdir -p $FILE_DIR 
sh $SCRIPTS_ROOT/func/show_process.sh
#复制bak成功的文件到 suc文件夹里
cp -a $STATIC_SRC/$LASTER_DIR/* $FILE_DIR
