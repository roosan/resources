#!/bin/bash
#功能描述：把加工好的war，放到tomcat服务器并重启服务。
#
#思路：
#1、删除服务器正在执行的资源
#2、获取最新一份资源，放到服务器
#3、重启tomcat
#4、探测是否所有的服务都活着
#5、如果都活着，把此次版本复制一份到成功目录，以便后期回滚

#作者: 庄君祥
#时间：2015年4月15日16:23:41
#版本：1.0

#脚本根目录
SCRIPTS_ROOT=/home/dev/scripts/deploy
#执行一下对应的全局变量
source $SCRIPTS_ROOT/baserc

DATE=`ls -n $STATIC_SUC|tail -1 |awk '{ print $9 }'`
#创建新的目录
ssh -p10022 $TARGET_USER@$TARGET_IP "mkdir -p $STATIC_SRC/$DATE"
#拷贝文件
scp -r -P 10022 $STATIC_SUC/$DATE/* $TARGET_USER@$TARGET_IP:$STATIC_SRC/$DATE
#远程执行发布脚本
source  ~/.bash_profile
source  /etc/profile 
ssh  -p10022 $TARGET_USER@$TARGET_IP "source  /etc/profile;/bin/sh $SCRIPTS_ROOT/deploy/static.sh"

