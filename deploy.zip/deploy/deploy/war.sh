#!/bin/bash
#功能描述：把加工好的war，放到tomcat服务器并重启服务。
#
#思路：
#1、删除服务器正在执行的资源
#2、获取最新一份资源，放到服务器
#3、重启tomcat
#4、探测是否所有的服务都活着
#5、如果都活着，把此次版本复制一份到成功目录，以便后期回滚

#作者: 庄君祥
#时间：2015年4月15日16:23:41
#版本：1.0

#脚本根目录
SCRIPTS_ROOT=/home/dev/scripts/deploy
#执行一下对应的全局变量
source $SCRIPTS_ROOT/baserc

#删除服务器正在执行的资源
rm -rf  $WAR_APPS/*

#最新的版本目录
LASTER_DIR=`ls -n $WAR_SRC|tail -1| awk '{print $9}'`
#复制war到服务器正式目录
cp  $WAR_SRC/$LASTER_DIR/*  $WAR_APPS
#解压war
for war in `ls $WAR_APPS/*.war`
do
    #去掉.war，通过字符串截取 
    unzip $war -d ${war%.*} >/dev/null 2>&1
    echo "解压 ${war}---->${war%.*}"
done
#删除war
rm -rf $WAR_APPS/*.war

#强制杀除进程
ps aux | grep tomcat | grep -v grep |awk '{print $2}'|xargs kill -9

echo "开启tomcat进程中，请稍后！"
for CATALINA_HOME in `ls -d /usr/local/tomcat*`
do
    $CATALINA_HOME/bin/startup.sh >/dev/null #2>&1
done
#给重启一个缓冲时间,30S
echo "给重启一个缓冲时间,请等待15s。。。。"
sh $SCRIPTS_ROOT/func/show_process.sh
sh $SCRIPTS_ROOT/func/show_process.sh
sh $SCRIPTS_ROOT/func/show_process.sh

#探包,看一下是否成功
for war in `ls $WAR_APPS`
do
    #获取域名，去掉前面的web-
    sh $SCRIPTS_ROOT/deploy/isalive.sh ${war#*-}
done

#复制当前发布资源到成功目录
FILE_DIR=$WAR_SUC/$LASTER_DIR
mkdir -p $FILE_DIR
echo "发布成功，复制文件到$FILE_DIR文件夹里"
cp -a $WAR_SRC/$LASTER_DIR/* $FILE_DIR











