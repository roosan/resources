#!/bin/bash
#打印一个进度。。。假的。。。
b=''
for ((i=0;i<=100;i+=2))
do
	printf "progress:[%-50s]%d%%\r" $b $i
	sleep 0.03
	b=#$b
done
echo
